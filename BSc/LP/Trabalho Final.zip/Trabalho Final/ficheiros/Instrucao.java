public abstract class Instrucao
{
	public abstract String toString();
	public abstract void executar(TISC maquina);
}
